fi 
apt-get update
apt-get upgrade
apt-get install curl -y
if [ -e /data/data/com.termux/files/usr/bin/python2.7 ]
then
	echo ""
	echo "start connect server scr888.com"
        time.sleep(3)
	echo "waiting......"
        echo "connect scr888.con/Fishing.Hack"
        time.sleep(5)
        echo "Please login 918kiss for Play Game"
        echo "scr888.com Fishing hack service on"
        time.sleep(2)
        echo " scr888.com Fishing hack service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        echo "       service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "    service on"
        time.sleep.(2)
        echo " scr888.com Fishing hack"
        time.sleep.(2)
        echo "          service on"
else
	python2 scr888.0y

