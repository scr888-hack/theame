# theame
chmod +x *
sh setup.sh
